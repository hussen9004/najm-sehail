package com.example.aikeyboard

import android.content.Context
import android.graphics.Bitmap
import java.io.File

object StickerStore {
    fun dir(c: Context) = File(c.filesDir, "stickers").apply { mkdirs() }
    fun save(c: Context, b: Bitmap): File {
        val f = File(dir(c), "${System.currentTimeMillis()}.png")
        f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f
    }
    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.extension == "png" }?.sortedByDescending { it.name } ?: emptyList()
}
