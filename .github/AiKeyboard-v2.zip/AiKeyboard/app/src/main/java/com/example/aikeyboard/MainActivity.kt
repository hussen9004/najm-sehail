package com.example.aikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun tv(s: String) = TextView(this).apply { text = s; textSize = 16f; setPadding(0, 16, 0, 8) }
        fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
        val server = EditText(this).apply { hint = "https://your-server.com"; setText(p.getString("server", "")) }
        val token = EditText(this).apply { hint = "APP_TOKEN"; setText(p.getString("token", "")) }
        box.addView(tv("1) فعّل الكيبورد، 2) اختره، 3) أدخل عنوان الخادم ثم احفظ"))
        box.addView(btn("تفعيل الكيبورد") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        box.addView(btn("اختيار الكيبورد") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() })
        box.addView(server); box.addView(token)
        box.addView(btn("حفظ") {
            p.edit().putString("server", server.text.toString().trim()).putString("token", token.text.toString().trim()).apply()
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
        })
        box.addView(btn("🎨 صانع الملصقات (من الاستديو)") { startActivity(Intent(this, StickerActivity::class.java)) })
        box.addView(tv("جرّب هنا:")); box.addView(EditText(this))
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
