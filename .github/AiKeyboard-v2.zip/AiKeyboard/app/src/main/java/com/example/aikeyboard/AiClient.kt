package com.example.aikeyboard

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    fun run(ctx: Context, mode: String, text: String, cb: (Result<String>) -> Unit) {
        Thread {
            cb(runCatching {
                val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
                val base = (p.getString("server", "") ?: "").trimEnd('/')
                val c = URL("$base/ai").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 30000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("x-app-token", p.getString("token", "") ?: "")
                c.outputStream.use { it.write(JSONObject().put("mode", mode).put("text", text).toString().toByteArray()) }
                if (c.responseCode != 200) error("HTTP ${c.responseCode}")
                JSONObject(c.inputStream.bufferedReader().readText()).getString("result")
            })
        }.start()
    }
}
